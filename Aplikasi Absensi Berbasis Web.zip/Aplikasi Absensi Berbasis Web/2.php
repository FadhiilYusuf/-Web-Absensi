<?php
//memanggil
$ambil_nim = $_POST['nim'];
$ambil_nama = $_POST['nama'];
$ambil_alamat = $_POST['alamat'];
$ambil_email = $_POST['email'];
$ambil_matakuliah = $_POST['mata_kuliah'];
$ambil_nilai = $_POST['nilai'];

// class dari mahasiswa
class Mahasiswa{

    //property untuk class mahasiswa
    var $nim;
    var $nama;
    var $alamat;
    var $email;
    var $mata_kuliah;
    var $nilai;

    //method untuk konstruktor
    function __construct()
    {
        echo "Data Mahasiswa PEI Jurusan RPL<br>";
        echo ""."<br>" ;
    }
    //method untuk class mahasiswa
    function krs($a, $i, $u, $e, $o, $r)
    {
        $this->nim = $a;
        $this->nama = $i;
        $this->alamat = $u;
        $this->email =$e;
        $this->mata_kuliah = $o;
        $this->nilai =$r;
    }
    function Absen($a, $i) {
        $this->nim = $a ;
        $this->nama = $i;
    }
    function Nilai($a, $o, $r) {
        $this->nim = $a ;
        $this->mata_kuliah = $o;
        $this->nilai = $r;
    }
    function Biodatamahasiswa($a, $i,  $u, $e) {
        $this->nim = $a;
        $this->nama = $i;
        $this->alamat = $u;
        $this->email =$e;
    }
    function Akunmahasiswa($a, $i, $e) {
        $this->nim = $a;
        $this->nama = $i;
        $this->email =$e;
    }
    //menampilkan method 
    function khs(){
        echo "Nim : ". $this->nim."<br>";
        echo "Nama : ". $this->nama."<br>";
        echo "Alamat: ". $this->alamat."<br>" ;
        echo "Email : ". $this->email."<br>";
        echo "MataKuliah : ". $this->mata_kuliah."<br>" ;
        echo "Nilai : ". $this->nilai."<br>" ;
        echo ""."<br>" ;
    }
    function absensi(){
        echo "Nim : ". $this->nim."<br>";
        echo "Nama : ". $this->nama."<br>";
        echo ""."<br>" ;
    }
    function penilaian(){
        echo "Nim : ". $this->nim."<br>";
        echo "MataKuliah : ". $this->mata_kuliah."<br>" ;
        echo "Nilai : ". $this->nilai."<br>" ;
        echo ""."<br>" ;
   }
    function Biodatamhs(){
        echo "Nim : ". $this->nim."<br>";
        echo "Nama : ". $this->nama."<br>";
        echo "Alamat: ". $this->alamat."<br>" ;
        echo "Email : ". $this->email."<br>";
        echo ""."<br>" ;
   }
    function Akun(){
        echo "Nim : ". $this->nim."<br>";
        echo "Nama : ". $this->nama."<br>";
        echo "Email : ". $this->email."<br>";
   }
 }
//objek dari class mahasiswa
$mhs = new Mahasiswa();
$mhs->krs($ambil_nim, $ambil_nama, $ambil_alamat, $ambil_email, $ambil_matakuliah, $ambil_nilai);
$mhs->khs();
//objek dari class mahasiswa
$mhu = new Mahasiswa();
$mhu->Absen($ambil_nim, $ambil_nama);
$mhu->absensi();
//objek dari class mahasiswa
$mhp = new Mahasiswa();
$mhp-> Nilai($ambil_nim, $ambil_matakuliah, $ambil_nilai);
$mhp->penilaian();
//objek dari class mahasiswa
$mhc = new Mahasiswa();
$mhc-> Biodatamahasiswa($ambil_nim, $ambil_nama, $ambil_alamat, $ambil_email);
$mhc->Biodatamhs();
//objek dari class mahasiswa
$mhd = new Mahasiswa();
$mhd-> Akunmahasiswa($ambil_nim, $ambil_nama, $ambil_email);
$mhd->Akun();
?>