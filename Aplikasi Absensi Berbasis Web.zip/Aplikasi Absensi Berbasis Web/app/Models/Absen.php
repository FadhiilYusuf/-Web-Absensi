<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Absen extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table ="absen";
    protected $primaryKey = "Id_absen";
    protected $fillable  =  ["Id_absen","Jam_hadir","Jam_pulang","Keterangan","Id_gaji","Id_pegawai"];

    public function Pegawai(){
        return $this->hasMany(Pegawai::class, 'Id_pegawai');
    }
    public function Gaji(){
        return $this->belongsTo(Gaji::class, 'Id_gaji"');
    }
}

