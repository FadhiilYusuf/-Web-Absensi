<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jabatan extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table ="jabataan";
    protected $primaryKey = "Id_jabatan";
    protected $fillable  =  ["Id_jabatan","Nama","Gaji","Id_pegawai"];

    public function Pegawai(){
        return $this->hasMany(Pegawai::class, 'Id_pegawai');
    }
}

