<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\File;

class Mahasiswa extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table ="mahasiswa";
    protected $primaryKey = "No";
    protected $fillable  =  ["No","Nama","Alamat","Email","Hp","Foto","File"];

}
