<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pegawai extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table ="pegawaii";
    protected $primaryKey = "Id_pegawai";
    protected $fillable  =  ["Id_pegawai","Nama","Nip","Jenis_kelamin","Alamat","Email","Hp","Foto","File"];

    public function Absen(){
        return $this->belongsTo(Absen::class, 'Id_pegawai');
    }
    public function Jabatan(){
        return $this->belongsTo(Jabatan::class, 'Id_pegawai');
    }
}
