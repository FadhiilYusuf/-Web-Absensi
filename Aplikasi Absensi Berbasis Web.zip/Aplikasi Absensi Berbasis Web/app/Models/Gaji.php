<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gaji extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table ="gaji";
    protected $primaryKey = "Id_gaji";
    protected $fillable  =  ["Id_gaji","Nama","Kode_gaji","Tanggal_gaji","Gaji_pokok","Tunjangan","Total_gaji","Id_absen"];

    public function Absen(){
        return $this->hasMany(Absen::class, 'Id_gaji');
    }
}

