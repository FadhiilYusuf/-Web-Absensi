<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class ControllerDull extends Controller
{
//Menampilkan Data
   public function DTD()
   {
       $a = DB::table('table_dosen')->get();
       return view('DataDsn',['data'=>$a]);
   }
   //Edite
   public function edit($id)
   {
       $data = DB::table('table_dosen')->where('Id_dosen',$id)->get();
       return view('DataEditDsn',['kirim' =>$data]);
   }
   //Update
   public function update(Request $x)
   {
       DB::table('table_dosen')->where('Id_dosen',$x->Id_dosen)->update([
           'nidn'=> $Nidn,
           'nama'=> $x->Nama,
           'alamat'=> $x->Alamat,
           'email'=>$x->Email,
           'hp'=>$x->Hp
       ]);
       return Redirect('/mhs');
   }
   // Delete
   public function hapus($id)
   {
       DB::table('table_dosen')->where('Id_dosen',$id)->delete();
       return redirect('/dsn');
   }
   // Inputan
   public function index()
   {
       $a = DB::table('table_dosen')->get();
       return view('/DataDsn',['data'=>$a]);
   }
   public function plus()
   {
       return view('InputanDsn');
   }
   public function simpan(Request $a)
   {
       DB::table('table_dosen')->insert([
          'nidn'=> $Nidn,
          'Nama' => $a->Nama,
          'Alamat'=> $a->Alamat,
          'Email'=> $a->Email,
          'Hp' => $a->Hp
       ]);
       return redirect('/dsn');
   }
}