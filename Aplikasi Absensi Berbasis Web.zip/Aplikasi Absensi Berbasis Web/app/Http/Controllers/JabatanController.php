<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Jabatan;


use File;


class JabatanController extends Controller
{
//Menampilkan Data
   public function indexx()
   {
       $dataGLGN = DB::table('jabataan')->paginate(5);

      return view('jabatan',['viewJBN'=>$dataGLGN]);
   }

   public function cariii (Request $x){
    $cari = $x -> cari;
    $dataGLGN = DB::table('jabataan')->where('Nama' ,'like',"%".$cari."%")->paginate();
     return view('jabatan',['viewJBN'=>$dataGLGN ]);
 }
    public function tambahann()
    {
        return view('jabatan-input');
    }
    public function simpanann(Request $a)
    {
        $messages = [
            'Nama.required' => 'Nama belum diisi. Isi dulu ya !',
            'Gaji.required' => 'Gaji belum diisi. Isi dulu ya ! ',
        ];
        $cekValidasi = $a->validate([
            'Nama' => 'required',
            'Gaji'=> 'required',
        ], $messages);
        if (empty($file)) {
        Jabatan::create([
        'Id_jabatan' => $a->Id_jabatan,
        'Nama' => $a->Nama,
        'Gaji' => $a->Gaji,
    ], $cekValidasi);
         } else {
         DB::table('jabataan')->insert([
        'Id_jabatan' => $a->Id_jabatan,
        'Nama' => $a->Nama,
        'Gaji' => $a->Gaji,
    ]);
}
return redirect('/jabatan')->with('toast_success', 'Data berhasil tambah!');
}
    public function edditt($Id_jabatan)
    {
        $dataGLGN  = Jabatan::find($Id_jabatan);
       return view('jabatan-edit',['jbn'=> $dataGLGN ]);
    }
    public function updatee( $Id_jabatan, Request $a )
    {
      DB::table('jabataan')->where('Id_jabatan', $a->Id_jabatan )->update([
        'Id_jabatan' => $a->Id_jabatan,
        'Nama' => $a->Nama,
        'Gaji' => $a->Gaji,
         ]);
       return redirect('/jabatan');
    }
 public function deletann ($Id_jabatan)
  {
    DB::table('jabataan')->where('Id_jabatan',$Id_jabatan)->delete();
    return redirect('/jabatan');
  }
}
