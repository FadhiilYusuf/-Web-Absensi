<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class ControllerDull extends Controller
{
//Menampilkan Data
   public function DTD()
   {
       $a = DB::table('table_dosen')->get();
       return view('DataDsn',['data'=>$a]);
   }
   //Edite
   public function editin($id)
   {
       $data = DB::table('table_dosen')->where('Id_dosen',$id)->get();
       return view('DataEditdsn',['kirim' =>$data]);
   }
   //Update
   public function updatein(Request $x)
   {
       DB::table('table_dosen')->where('Id_dosen',$x->Id_dosen)->update([
           'nidn'=> $x->Nidn,
           'nama'=> $x->Nama,
           'alamat'=> $x->Alamat,
           'email'=>$x->Email,
           'hp'=>$x->Hp
       ]);
       return Redirect('/dsn');
   }
   // Delete
   public function hapusin($id)
   {
       DB::table('table_dosen')->where('Id_dosen',$id)->delete();
       return redirect('/dsn');
   }
   // Inputan
   public function indexx()
   {
       $a = DB::table('table_dosen')->get();
       return view('/DataDsn',['data'=>$a]);
   }
   public function tambah()
   {
       return view('Inputandsn');
   }
   public function simpanan(Request $a)
   {
       DB::table('table_dosen')->insert([
          'nidn'=> $a -> Nidn,
          'Nama' => $a->Nama,
          'Alamat'=> $a->Alamat,
          'Email'=> $a->Email,
          'Hp' => $a->Hp
       ]);
       return redirect('/dsn');
   }
}