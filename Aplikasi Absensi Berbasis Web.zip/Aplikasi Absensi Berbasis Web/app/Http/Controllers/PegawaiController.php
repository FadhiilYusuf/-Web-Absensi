<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Pegawai;

use File;


use App\Http\Controllers\Controller;
use App\Models\Jabatan;

class PegawaiController extends Controller
{
//Menampilkan Data

   public function tampilpegawai()
   {
       $data2 = Pegawai::count();
    $keluar = Jabatan::count();
    $data = [$data2, $keluar];

    return view("templates",['data'=>$data] );
   }
   public function tampilprofil()
   {
      return view('profile');
   }
   public function index()
   {
       $dataPGW = DB::table('pegawaii')->paginate(3);

      return view('karyawan',['viewPGW'=>$dataPGW]);
   }

   public function carii (Request $x){
    $cari = $x -> cari;
    $dataPGW = DB::table('pegawaii')->where('Nama' ,'like',"%".$cari."%")->paginate();
     return view('karyawan',['viewPGW'=>$dataPGW]);
 }
    public function tambahan()
    {
        $Id_jabatan = Jabatan::all();
        return view("karyawan-input", ['viewPGW' => $Id_jabatan]);
    }
    public function simpanan(  Request $a )
    {
        $messages = [
            'Nip.required' => 'Nip belum diisi. Isi dulu ya !',
            'Nama.required' => 'Nama belum diisi. Isi dulu ya !',
            'Alamat.required' => 'Alamat belum diisi. Isi dulu ya ! ',
            'Email.required' => 'Email belum diisi. Isi dulu ya !',
            'Id_jabatan.required' => 'Jabatan belum diisi. Isi dulu ya !',
            'Foto.required' => 'Foto Belum di upload !',
            'image ' => 'File yang di upload bukan image'
        ];
        $cekValidasi = $a->validate([
            'Nip' => 'required',
            'Nama' => 'required',
            'Alamat'=> 'required',
            'Email' => 'required',
            'Id_jabatan' =>'required',
            'Foto' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
        ], $messages);

       $file = $a->file('Foto');
       if (empty($file)) {
        Pegawai::create([
            'Id_pegawai' => $a->Id_pegawai,
            'Nip' => $a->Nip,
            'Nama' => $a->Nama,
            'Jenis_kelamin' => $a->Jenis_kelamin,
            'Alamat'=> $a->Alamat,
            'Email' => $a->Email,
            'Id_jabatan' => $a->Id_jabatan,
        ], $cekValidasi);
    } else {
       $nama_file = time()."-".$file ->getClientOriginalName();
       $ekstensi = $file->getClientOriginalExtension();
       $ukuran = $file->getSize();
       $pathAsli = $file->getRealPath();
       $namaFolder = 'Foto';
       $file->move($namaFolder, $nama_file);
       $pathPublic = $namaFolder."/".$nama_file;

       DB::table('pegawaii')->insert([
        'Id_pegawai' => $a->Id_pegawai,
        'Nip' => $a->Nip,
        'Nama' => $a->Nama,
        'Jenis_kelamin' => $a->Jenis_kelamin,
        'Alamat'=> $a->Alamat,
        'Email' => $a->Email,
        'Id_jabatan' => $a->Id_jabatan,
        'Foto' => $pathPublic,
    ]);
}
return redirect('/karyawan')->with('toast_success', 'Data berhasil tambah!');
}
    public function edit($Id_pegawai)
    {
        $Id_jabatan = Jabatan::all();
        $dataPGW = Pegawai::find($Id_pegawai);
        return view('karyawan-edit',['pgw'=> $dataPGW],['viewPGW' => $Id_jabatan]);
    }
    public function update( $Id_pegawai, Request $a )
    {
    $file = $a->file('Foto');
      if (file_exists($file)) {
         $nama_file = time() . "-" .$file ->getClientOriginalName();
         $folder = 'Foto';
         $file->move($folder,$nama_file);
         $path = $folder."/".$nama_file;
      }else {
         $path = $a->pathfoto;
      }

      DB::table('pegawaii')->where('Id_pegawai', $a->Id_pegawai )->update([
        'Id_pegawai' => $a->Id_pegawai,
        'Nip' => $a->Nip,
        'Nama' => $a->Nama,
        'Jenis_kelamin' => $a->Jenis_kelamin,
        'Alamat'=> $a->Alamat,
        'Email' => $a->Email,
        'Id_jabatan' => $a->Id_jabatan,
        'Foto' => $path
         ]);
       return redirect('/karyawan');
    }
 public function deletan ($Id_pegawai)
  {
    $dataPGW = DB::table('pegawaii')->where('Id_pegawai',$Id_pegawai)->first();
    File::delete($dataPGW->Foto);
    DB::table('pegawaii')->where('Id_pegawai',$Id_pegawai)->delete();
    return redirect('/karyawan');
  }
}

