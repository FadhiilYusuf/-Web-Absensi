<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;


class LoginController extends Controller
{
    //Tampilan Login
    public function viewLogin(){
        return view('login');
    }

    public function login (Request $a){
        $messages = [
            'email.required' => 'Email tidak boleh kosong!',
            'password.required' => 'Password tidak boleh kosong!',
        ];
        $cek = $a->validate([
            //'email' => 'required|email:dns|unique:users',
            'email' => 'required',
            'password' => 'required|max:50'
        ], $messages);

        if(Auth::attempt($cek)){
            $a->session()->regenerate();
            return redirect()->intended('/dashboar');
        }

        return back()->with('LoginError', 'Maap! Gagal Login');
    }
           public function logout(Request $a){
            Auth::logout();
            $a->session()->invalidate();
            $a->session()->regenerateToken();
            return redirect('viewLogin');
        }
        public function viewLoginn(){
            return view('logiin');
        }
        public function logiin (Request $a){
            $messages = [
                'email.required' => 'Email tidak boleh kosong!',
                'password.required' => 'Password tidak boleh kosong!',
            ];
            $cek = $a->validate([
                //'email' => 'required|email:dns|unique:users',
                'email' => 'required',
                'password' => 'required|max:50'
            ], $messages);

            if(Auth::attempt($cek)){
                $a->session()->regenerate();
                return redirect()->intended('/dashboaard');
            }

            return back()->with('LoginError', 'Maap! Gagal Login');
        }
               public function logouut(Request $a){
                Auth::logout();
                $a->session()->invalidate();
                $a->session()->regenerateToken();
                return redirect('viewLoginn');
            }
        public function iiindeexx()
        {
            $dataDtusr = DB::table('users')->paginate(5);

           return view('DtUsr',['viewdtUsr'=>$dataDtusr]);
        }
        //input data user
        public function ttambbahann()
        {
           return view('DtUsr-input');
        }
        public function ssiimpanann(Request $a)
        {
            $messages = [
                'nama.required' => 'Nama belum diisi. Isi dulu ya !',
                'email.required' => 'email belum diisi. Isi dulu ya !',
                'password.required' => 'password belum diisi. Isi dulu ya ! ',
            ];
            $cekValidasi = $a->validate([
                'name' => 'required',
                'email' => 'required',
                'password'=> 'required',
            ], $messages);
            if (empty($file)) {
             User::create([
            'id' => $a->id,
            'name' => $a->name,
            'email' => $a->email,
            'password' =>  bcrypt($a['password']),
        ], $cekValidasi);
             } else {
             DB::table('users')->insert([
               'id' => $a->id,
               'name' => $a->name,
               'email' => $a->email,
               'password' => bcrypt($a['password']),
        ]);
       }
       return redirect('/DataUser')->with('Data berhasil tambah!');
    }

        //edit data user
        public function editUser($id)
        {
            $dataUser = User::find($id);
            return view("DtUsr-edit", ['usrr' => $dataUser]);
        }

        public function updateUser( $id, Request $a )
        {
          DB::table('users')->where('id', $a->id )->update([
            'id' => $a->id,
            'name' => $a->name,
            'email' => $a->email,
            'password' =>  bcrypt($a['password']),
             ]);
           return redirect('/DataUser');
        }
     public function ddelettaann ($id)
      {
        DB::table('users')->where('id',$id)->delete();
        return redirect('/DataUser');
      }
    }

