<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DktrController extends Controller
{
    //
    public function data()
    {
        return view('coba');
    }
    public function nip()
    {
        return "ini adalah method Nip";
    }
    public function nama()
    {
        return "ini adalah method Nama";
    }
    public function jabatan()
    {
        return "ini adalah method Jabatan";
    }
    public function gaji ()
    {
        return "ini adalah method gaji";
    }
}
