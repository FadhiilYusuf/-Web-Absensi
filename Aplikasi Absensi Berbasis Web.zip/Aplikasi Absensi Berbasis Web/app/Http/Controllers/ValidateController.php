<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Mahasiswa;

use Illuminate\Support\Facades\DB;

class ValidateController extends Controller
{
    public function simpan (Request $a)
    {
        $cekValidasi = $a->validate([
            'Nim' => 'required',
            'Nama' => 'required',
            'Alamat'=> 'required'
        ]);
        Mahasiswa::create($cekValidasi);
        return redirect('/lihat')->with('berhasil','data berhasil simpan!');
    }
}
