<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Gaji;
use App\Models\Absen;

use File;


class GajiController extends Controller
{
//Menampilkan Data

public function iindeexx()
{
    $dataGJI = DB::table('gaji')->paginate(5);

   return view('gajian',['viewGJI'=>$dataGJI]);
}
 public function tambbahann()
 {
    $Id_absen = Absen::all();
    return view("gajian-input", ['viewGJI' => $Id_absen]);
 }
 public function siimpanann(Request $a)
 {
     $messages = [
         'Nama.required' => 'Nama belum diisi. Isi dulu ya !',
         'Kode_gaji.required' => 'Kode gaji belum diisi. Isi dulu ya !',
         'Tanggal_gaji.required' => 'Tanggal belum diisi. Isi dulu ya ! ',
         'Gaji_pokok.required' => 'Gaji belum diisi. Isi dulu ya ! ',
         'Tunjangan.required' => 'Tunjangan belum diisi. Isi dulu ya ! ',
         'Total_gaji.required' => 'Gaji belum diisi. Isi dulu ya ! ',
     ];
     $cekValidasi = $a->validate([
         'Nama' => 'required',
         'Kode_gaji' => 'required',
         'Tanggal_gaji'=> 'required',
         'Gaji_pokok'=> 'required',
         'Tunjangan'=> 'required',
         'Total_gaji' => 'required',
         'Id_absen' => 'required',
     ], $messages);
     if (empty($file)) {
      Gaji::create([
     'Id_gaji' => $a->Id_gaji,
     'Nama' => $a->Nama,
     'Kode_gaji' => $a->Kode_gaji,
     'Tanggal_gaji' => $a->	Tanggal_gaji,
     'Gaji_pokok' => $a->Gaji_pokok,
     'Tunjangan' => $a->Tunjangan,
     'Total_gaji'=> $a->Total_gaji,
     'Id_absen' => $a->Id_absen,
 ], $cekValidasi);
      } else {
      DB::table('gaji')->insert([
        'Id_gaji' => $a->Id_gaji,
        'Nama' => $a->Nama,
        'Kode_gaji' => $a->Kode_gaji,
        'Tanggal_gaji' => $a->	Tanggal_gaji,
        'Gaji_pokok' => $a->Gaji_pokok,
        'Tunjangan' => $a->Tunjangan,
        'Total_gaji'=> $a->Total_gaji,
        'Id_absen' => $a->Id_absen,
 ]);
}
return redirect('/gajii')->with('toast_success', 'Data berhasil tambah!');
}
public function edittt($Id_gaji)
{
    $Id_absen = Absen::all();
    $dataGJI = Gaji::find($Id_gaji);
    return view('gajian-edit',['gi'=> $dataGJI],['viewGJI' => $Id_absen]);
}
 public function updateee( $Id_gaji, Request $a )
 {
   DB::table('gaji')->where('Id_gaji', $a->Id_gaji)->update([
        'Id_gaji' => $a->Id_gaji,
        'Nama' => $a->Nama,
        'Kode_gaji' => $a->Kode_gaji,
        'Tanggal_gaji' => $a->Tanggal_gaji,
        'Gaji_pokok' => $a->Gaji_pokok,
        'Tunjangan' => $a->Tunjangan,
        'Total_gaji'=> $a->Total_gaji,
        'Id_absen' => $a->Id_absen,
      ]);
    return redirect('/gajii');
 }
public function delettaann ($Id_gaji)
{
 DB::table('gaji')->where('Id_gaji',$Id_gaji)->delete();
 return redirect('/gajii');
}
}
