<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Pegawai;

use App\Models\Absen;



use File;


use App\Http\Controllers\Controller;
use App\Models\Jabatan;

class UserController extends Controller
{
//Menampilkan Data

   public function tampiluser()
   {
    $data2 = Pegawai::count();
    $keluar = Jabatan::count();
    $data = [$data2, $keluar];

    return view("templatess",['data'=>$data] );

   }
   public function tampilprofil()
   {
      return view('profile');
   }
   public function innndex()
   {
       $dataPGW = DB::table('pegawaii')->paginate(3);

      return view('karyawanusr',['viewPGW'=>$dataPGW]);
   }
   public function innndexx()
   {
    $dataGLGN = DB::table('jabataan')->paginate(5);

    return view('jabatanusr',['viewJBN'=>$dataGLGN]);
   }
   public function innndexxx()
   {
    $dataGJI = DB::table('gaji')->paginate(5);

    return view('gajianusr',['viewGJI'=>$dataGJI]);
   }

   public function tttaambahann()
   {
       $Id_pegawai = Pegawai::all();
       return view("absensiusr-input", ['viewABN' => $Id_pegawai]);
   }
public function sssimpanann(Request $a)
{
   $messages = [
       'Keterangan.required' => 'keterangan belum diisi. Isi dulu ya ! ',
       'Jam_pulang.required' => 'Jam_pulang belum diisi. Isi dulu ya ! ',
       'Id_pegawai.required' => 'pegawai belum diisi. Isi dulu ya ! ',
   ];
   $cekValidasi = $a->validate([
       'Keterangan' => 'required',
       'Jam_pulang' => 'required',
       'Id_pegawai' => 'required',
   ], $messages);
   if (empty($file)) {
       Absen::create([
       'Id_absen' => $a->Id_absen,
       'Jam_hadir' => $a->Jam_hadir,
       'Jam_pulang' => $a->Jam_pulang,
       'Keterangan' => $a->Keterangan,
       'Id_pegawai' => $a->Id_pegawai,
], $cekValidasi);
    } else {
    DB::table('absen')->insert([
   'Id_absen' => $a->Id_absen,
   'Jam_hadir' => $a->Jam_hadir,
   'Jam_pulang' => $a->Jam_pulang,
   'Keterangan' => $a->Keterangan,
   'Id_pegawai' => $a->Id_pegawai,
]);
}
     return redirect('/tmbhabsnusr')->with('Data berhasil tambah!');
}

}

