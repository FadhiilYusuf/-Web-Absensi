<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SswController extends Controller
{
   //
   public function one()
   {
       return view('contoh');
   }
   public function two()
   {
       return "ini two";
   }
   public function three()
   {
       return "ini three";
   }
   public function four()
   {
       return "ini four";
   }
   public function five()
   {
       return "ini five";
   }
}
