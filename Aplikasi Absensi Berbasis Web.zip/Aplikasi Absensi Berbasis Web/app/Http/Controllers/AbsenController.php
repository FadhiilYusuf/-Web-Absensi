<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Absen;
use App\Models\Pegawai;
use File;


class AbsenController extends Controller
{
//Menampilkan Data

    public function indexxxx()
    {
        $dataABN = DB::table('absen')->paginate(5);

        return view('absensi',['viewABN'=>$dataABN]);

    }
    public function carii (Request $x){
        $cari = $x -> cari;
        $dataABN = DB::table('absen')->where('Keterangan' ,'like',"%".$cari."%")->paginate();
         return view('absensi',['viewABN'=>$dataABN]);
     }
        public function ttambahann()
        {
            $Id_pegawai = Pegawai::all();
            return view("absensi-input", ['viewABN' => $Id_pegawai]);
        }
    public function ssimpanann(Request $a)
    {
        $messages = [
            'Keterangan.required' => 'keterangan belum diisi. Isi dulu ya ! ',
            'Jam_pulang.required' => 'Jam_pulang belum diisi. Isi dulu ya ! ',
            'Id_pegawai.required' => 'pegawai belum diisi. Isi dulu ya ! ',
        ];
        $cekValidasi = $a->validate([
            'Keterangan' => 'required',
            'Jam_pulang' => 'required',
            'Id_pegawai' => 'required',
        ], $messages);
        if (empty($file)) {
            Absen::create([
            'Id_absen' => $a->Id_absen,
            'Jam_hadir' => $a->Jam_hadir,
            'Jam_pulang' => $a->Jam_pulang,
            'Keterangan' => $a->Keterangan,
            'Id_pegawai' => $a->Id_pegawai,
    ], $cekValidasi);
         } else {
         DB::table('absen')->insert([
        'Id_absen' => $a->Id_absen,
        'Jam_hadir' => $a->Jam_hadir,
        'Jam_pulang' => $a->Jam_pulang,
        'Keterangan' => $a->Keterangan,
        'Id_pegawai' => $a->Id_pegawai,
    ]);
}
          return redirect('/absensi')->with('Data berhasil tambah!');
}
public function ediitttt($Id_absen)
{
    $Id_pegawai = Pegawai::all();
    $dataABN = Absen::find($Id_absen);
    return view('absensi-edit',['abn'=> $dataABN],['viewABN'=> $Id_pegawai]);
}
 public function uppdateeee( $Id_absen, Request $a )
 {
   DB::table('absen')->where('Id_absen', $a->Id_absen)->update([
    'Id_absen' => $a->Id_absen,
    'Jam_hadir' => $a->Jam_hadir,
    'Jam_pulang' => $a->Jam_pulang,
    'Keterangan' => $a->Keterangan,
    'Id_pegawai' => $a->Id_pegawai,
      ]);
    return redirect('/absensi');
 }
public function delettaan ($Id_absen)
{
  $dataPGW = DB::table('absen')->where('Id_absen',$Id_absen)->first();
  DB::table('absen')->where('Id_absen',$Id_absen)->delete();
  return redirect('/absensi');
}
}
