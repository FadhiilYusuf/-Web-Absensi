<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class ControllerDill extends Controller
{
//Menampilkan Data
   public function DTM()
   {
       $a = DB::table('table_mahasiswa')->get();
       return view('DataMhs',['data'=>$a]);
   }
   //Edite
   public function edit($id)
   {
       $data = DB::table('table_mahasiswa')->where('NIM',$id)->get();
       return view('DataEditMHS',['kirim' =>$data]);
   }
   //Update
   public function update(Request $x)
   {
       DB::table('table_mahasiswa')->where('nim',$x->Nim)->update([
           'nama'=> $x->Nama,
           'alamat'=> $x->Alamat,
           'email'=>$x->Email,
           'hp'=>$x->Hp,
           'id_dosen' =>$x->Id_dosen
       ]);
       return Redirect('/mhs');
   }
   // Delete
   public function hapus($id)
   {
       DB::table('table_mahasiswa')->where('Nim',$id)->delete();
       return redirect('/mhs');
   }
   // Inputan
   public function index()
   {
       $a = DB::table('table_mahasiswa')->get();
       return view('/DataMsh',['data'=>$a]);
   }
   public function plus()
   {
       return view('InputanMHS');
   }
   public function simpan(Request $a)
   {
       DB::table('table_mahasiswa')->insert([
          'Nim' => $a->Nim,
          'Nama' => $a->Nama,
          'Alamat'=> $a->Alamat,
          'Email'=> $a->Email,
          'Hp' => $a->Hp,
          'Id_dosen' => $a->Id_dosen
       ]);
       return redirect('/mhs');
   }
}