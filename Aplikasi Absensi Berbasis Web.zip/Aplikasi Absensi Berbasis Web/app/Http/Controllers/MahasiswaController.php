<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Storage;

use App\Models\Mahasiswa;

use File;

class MahasiswaController extends Controller
{
//Menampilkan Data

   public function index()
   {
       $dataMhs = DB::table('Mahasiswa')->paginate(5);

      return view('mahasiswa',['viewMhs'=>$dataMhs]);
   }
   public function cari (Request $x){
      $cari = $x -> cari;
      $dataMhs = DB::table('mahasiswa')->where('Nama' ,'like',"%".$cari."%")->paginate();
       return view('mahasiswa',['viewMhs'=>$dataMhs]);
   }
      public function tambah()
      {
         return view('mahasiswa-input');
      }
      public function simpan(  Request $a )
      {
         $file = $a->file('poto');
         $nama_file = time()."-".$file ->getClientOriginalName();
         $ekstensi = $file->getClientOriginalExtension();
         $ukuran = $file->getSize();
         $pathAsli = $file->getRealPath();
         $namaFolder = "poto";
         $file->move($namaFolder, $nama_file);
         $pathPublic = $namaFolder."/".$nama_file;

         DB::table('mahasiswa')->insert([
          'Nim' => $a->Nim,
          'Nama' => $a->Nama,
          'Alamat'=> $a->Alamat,
          'Email' => $a->Email,
          'Hp' => $a->Hp,
          'poto' => $pathPublic
         ]);
         return redirect('/lihat');
      }
         public function edit($Nim)
      {
         $dataMhs = Mahasiswa::find($Nim);
         return view('mahasiswa-edit',['mhs'=>$dataMhs]);
      }
      public function update( $Nim, Request $a )
      {
      $file = $a->file('poto');
        if (file_exists($file)) {
           $nama_file = time() . "-" .$file ->getClientOriginalName();
           $folder = 'poto';
           $file->move($folder,$nama_file);
           $path = $folder."/".$nama_file;
        }else {
           $path = $a->pathfoto;
        }

        DB::table('mahasiswa')->where('nim', $a->Nim )->update([
         'Nim' => $a->Nim,
         'Nama' => $a->Nama,
         'Alamat'=> $a->Alamat,
         'Email' => $a->Email,
         'Hp' => $a->Hp,
         'poto' => $path
           ]);
         return redirect('/lihat');
      }
   public function delete ($Nim)
    {
      $dataMhs = DB::table('mahasiswa')->where('nim',$Nim)->first();
      File::delete($dataMhs->poto);
      DB::table('mahasiswa')->where('nim',$Nim)->delete();
      return redirect('/lihat');
    }
}
