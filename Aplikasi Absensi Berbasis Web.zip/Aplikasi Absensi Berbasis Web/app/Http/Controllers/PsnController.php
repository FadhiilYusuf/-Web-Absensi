<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PsnController extends Controller
{
   //
   public function template()
   {
       return view('template');
   }
   public function Adill()
   {
       return view('dill');
   }
   public function Nama()
   {
       return "ini adalah method Nama";
   }
   public function NoAntrian()
   {
       return "ini adalah method No Antrian";
   }
   public function Gejala()
   {
       return "ini adalah method Gejala";
   }
   public function Tanggalcek()
   {
       return "ini adalah Tanggal Cek";
   }
}
